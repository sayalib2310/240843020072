
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./pages/Layout";
import HomePage from "./pages/HomePage";
import Dashboard from "./pages/Dashboard";
import UserRegistration from "./pages/UserRegistration";
import UserLogin from "./pages/UserLogin";
import AdminDashboard from "./pages/AdminDashboard";
// import AdminLogin from "./pages/AdminLogin";

function App() {
  return ( 
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="register" element={<UserRegistration />} />
          <Route path="login" element={<UserLogin />} />
          {/* <Route path="admin-login" element={<AdminLogin />} /> */}
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="admin-dashboard" element={<AdminDashboard />} />
          
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
