import React from 'react'
import { Container, Navbar, Nav, Button, Row, Col, Card } from 'react-bootstrap';

export default function HomePage() {
  return (
    <div className="bg-light">
    {/* Hero Section */}
    <header className="bg-primary text-white text-center py-5">
      <div className="container">
        <h1 className="display-4 fw-bold">Garbage Guru</h1>
        <p className="lead">Your Smart Waste Management Partner</p>
        <a href="#features" className="btn btn-outline-light btn-lg mt-3">Learn More</a>
      </div>
    </header>

    {/* Features Section */}
    <section id="features" className="py-5">
      <div className="container">
        <h2 className="text-center mb-4">Why Choose Garbage Guru?</h2>
        <div className="row">
          <div className="col-md-4 text-center mb-4">
            <div className="p-4 border rounded shadow">
              <i className="bi bi-recycle display-4 text-success mb-3"></i>
              <h4>Eco-Friendly Solutions</h4>
              <p>We provide sustainable waste management practices to protect our environment.</p>
            </div>
          </div>
          <div className="col-md-4 text-center mb-4">
            <div className="p-4 border rounded shadow">
              <i className="bi bi-map display-4 text-primary mb-3"></i>
              <h4>Smart Pickup Scheduling</h4>
              <p>Automate your waste pickups with smart scheduling and real-time tracking.</p>
            </div>
          </div>
          <div className="col-md-4 text-center mb-4">
            <div className="p-4 border rounded shadow">
              <i className="bi bi-bar-chart display-4 text-warning mb-3"></i>
              <h4>Data-Driven Insights</h4>
              <p>Access insightful analytics to optimize waste collection and disposal.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    {/* Call to Action Section */}
    <section className="bg-dark text-white py-5">
      <div className="container text-center">
        <h2>Ready to Make a Difference?</h2>
        <p className="lead">Join us in revolutionizing waste management and creating a cleaner future.</p>
        <a href="#contact" className="btn btn-outline-light btn-lg mt-3">Get Started</a>
      </div>
    </section>

    {/* Contact Section */}
    <section id="contact" className="py-5">
      <div className="container">
        <h2 className="text-center mb-4">Contact Us</h2>
        <div className="row">
          <div className="col-md-6 mb-4">
            <h5>Address</h5>
            <p>123 Eco Street, Green City, Planet Earth</p>
          </div>
          <div className="col-md-6 mb-4">
            <h5>Email & Phone</h5>
            <p>Email: support@garbageguru.com</p>
            <p>Phone: +1 (555) 123-4567</p>
          </div>
        </div>
      </div>
    </section>

    {/* Footer */}
    <footer className="bg-primary text-white text-center py-3">
      <div className="container">
        <p className="mb-0">&copy; {new Date().getFullYear()} Garbage Guru. All Rights Reserved.</p>
      </div>
    </footer>
  </div>
  )
}
