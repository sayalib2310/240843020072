import React from 'react';
import { useForm } from 'react-hook-form';
import SweetAlert from 'sweetalert2';
import { registerUser } from '../utils/api-request';

const UserRegistration = () => {
    const { register, handleSubmit, formState: { errors } } = useForm();
    
    async function onSubmit(data) {
        console.log(data);

        const result = await registerUser({...data,roleId:1});
        if (result.success) {
            console.log(result.data);
            
            SweetAlert.fire('Success', 'User registered successfully!', 'success');
        } else {
            SweetAlert.fire('Error', `User registered failed! <br/>${result.error}`, 'error');
        }
    }


    return (
        <div className="d-flex justify-content-center">
            <form onSubmit={handleSubmit(onSubmit)} className="border p-4 w-50">
                <h3>Register User</h3>

                {/* First Name */}
                <div className="mb-3">
                    <label htmlFor="firstName" className="form-label">First Name</label>
                    <input
                        type="text"
                        className="form-control"
                        id="firstName"
                        {...register('firstName', { required: 'First name is required' })}
                    />
                    {errors.firstName && <small className="text-danger">{errors.firstName.message}</small>}
                </div>

                {/* Last Name */}
                <div className="mb-3">
                    <label htmlFor="lastName" className="form-label">Last Name</label>
                    <input
                        type="text"
                        className="form-control"
                        id="lastName"
                        {...register('lastName', { required: 'Last name is required' })}
                    />
                    {errors.lastName && <small className="text-danger">{errors.lastName.message}</small>}
                </div>

                {/* Username */}
                <div className="mb-3">
                    <label htmlFor="userName" className="form-label">Username</label>
                    <input
                        type="text"
                        className="form-control"
                        id="userName"
                        {...register('userName', {
                            required: 'Username is required',
                            pattern: {
                                value: /^[A-Za-z0-9_]+$/,
                                message: 'Username can only contain letters, numbers, and underscores (_), no spaces allowed.'
                            }
                        })}
                    />
                    {errors.userName && <small className="text-danger">{errors.userName.message}</small>}
                </div>

                {/* Email ID */}
                <div className="mb-3">
                    <label htmlFor="emailId" className="form-label">Email Address</label>
                    <input
                        type="email"
                        className="form-control"
                        id="emailId"
                        {...register('emailId', { required: 'Email is required' })}
                    />
                    {errors.emailId && <small className="text-danger">{errors.emailId.message}</small>}
                </div>

                {/* Password */}
                <div className="mb-3">
                    <label htmlFor="password" className="form-label">Password</label>
                    <input
                        type="password"
                        className="form-control"
                        id="password"
                        {...register('password', {
                            required: 'Password is required',
                            minLength: {
                                value: 6,
                                message: 'Password must be at least 6 characters long'
                            },
                            pattern: {
                                value: /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/,
                                message: 'Password must include at least one letter, one number, and one special character'
                            }
                        })}
                    />
                    {errors.password && <small className="text-danger">{errors.password.message}</small>}
                </div>

                {/* Contact Number */}
                <div className="mb-3">
                    <label htmlFor="contactNo" className="form-label">Contact Number</label>
                    <input
                        type="text"
                        className="form-control"
                        id="contactNo"
                        {...register('contactNo', {
                            required: 'Contact number is required',
                            pattern: {
                                value: /^[0-9]{10}$/,
                                message: 'Contact number must be 10 digits long'
                            }
                        })}
                    />
                    {errors.contactNo && <small className="text-danger">{errors.contactNo.message}</small>}
                </div>

                {/* Aadhar Number */}
                <div className="mb-3">
                    <label htmlFor="aadharNo" className="form-label">Aadhar Number</label>
                    <input
                        type="text"
                        className="form-control"
                        id="aadharNo"
                        {...register('aadharNo', {
                            required: 'Aadhar number is required',
                            pattern: {
                                value: /^[0-9]{12}$/,
                                message: 'Aadhar number must be exactly 12 digits long'
                            }
                        })}
                    />
                    {errors.aadharNo && <small className="text-danger">{errors.aadharNo.message}</small>}
                </div>

                {/* Submit Button */}
                <div className="mb-3">
                    <button type="submit" className="btn btn-primary">Register</button>
                </div>
            </form>
        </div>
    );
};

export default UserRegistration;
