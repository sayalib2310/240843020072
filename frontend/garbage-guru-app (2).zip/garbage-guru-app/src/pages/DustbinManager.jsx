import React, { useState, useEffect } from 'react';
import { Button, Modal, Form, Table } from 'react-bootstrap';
import SweetAlert from 'sweetalert2';
import { getDustbins, addDustbin, updateDustbin, deleteDustbin, getBasicInfo, getUsersList } from '../utils/api-request';
import axios from 'axios';

export default function DustbinManager() {
    const [dustbins, setDustbins] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [showAddModal, setShowAddModal] = useState(false);
    const [showUpdateModal, setShowUpdateModal] = useState(false);
    const [selectedDustbin, setSelectedDustbin] = useState(null);
    const [usersList, setUsersList] = useState([]);
    const filterList = dustbins.filter(
        (dustbin) =>
            dustbin?.dustNo?.toString().includes(searchQuery)
    );


    const [formData, setFormData] = useState({
        allocatedDate: '',
        lastCleanDate: '',
        garbageQtyInKg: '',
        statusId: null,
        areaId: null,
        userId: null,
        categoryId: null,
        dustNo: ''
    });


    function transformToNewFormat(formData) {
        return {
            allocatedDate: formData.allocatedDate,
            lastCleanDate: formData.lastCleanDate,
            garbageQtyInKg: parseInt(formData.garbageQtyInKg),
            statusId: parseInt(formData.statusId),
            areaId: parseInt(formData.areaId),
            userId: parseInt(formData.userId),
            categoryId: parseInt(formData.categoryId),
            dustNo: parseInt(formData.dustNo),

        };
    }

    const [basicInfo, setBasicInfo] = useState({
        category: [],
        address: [],
        status: []
    });

    async function fetchDustbins() {
        const response = await getDustbins();
        if (response.success) {
            setDustbins(response.data);
            // setFilterList(response.data);
        }
    }
    useEffect(() => {

        fetchDustbins();
    }, []);

    useEffect(() => {
        async function fetchBasicInfo() {
            try {
                const response = await getBasicInfo();
                const userList = await getUsersList();
                console.log(userList);
                setUsersList(userList.data);
                setBasicInfo(response.data);
            } catch (error) {
                console.error('Error fetching basic info:', error);
            }
        }
        fetchBasicInfo();
    }, []);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };


    async function handleAddDustbin(e) {
        e.preventDefault();
        console.log(formData);

        const response = await addDustbin(transformToNewFormat(formData));

        if (response.success) {
            setShowAddModal(false);
            SweetAlert.fire('Success', 'Dustbin added successfully!', 'success');
            fetchDustbins();
        } else {
            SweetAlert.fire('Error', 'Failed to add dustbin!', 'error');
        }
    }


    async function handleUpdateDustbin(e) {
        e.preventDefault();
        const response = await updateDustbin(selectedDustbin.dustbinId, formData);
        if (response.success) {
            setShowUpdateModal(false);
            SweetAlert.fire('Success', 'Dustbin updated successfully!', 'success');
            setDustbins(
                dustbins.map((dustbin) =>
                    dustbin.dustbinId === selectedDustbin.dustbinId ? response.data : dustbin
                )
            );
        } else {
            SweetAlert.fire('Error', 'Failed to update dustbin!', 'error');
        }
    }

    // Handle Delete Dustbin
    async function handleDeleteDustbin(dustbinId) {
        const response = await deleteDustbin(dustbinId);
        if (response.success) {
            SweetAlert.fire('Success', 'Dustbin deleted successfully!', 'success');
            setDustbins(dustbins.filter((dustbin) => dustbin.dustbinId !== dustbinId));
        } else {
            SweetAlert.fire('Error', 'Failed to delete dustbin!', 'error');
        }
    }



    return (
        <div className="container mt-4">
            <h3>Dustbin Manager</h3>
            <div className="d-flex justify-content-between mb-3">
                <input
                    type="text"
                    className="form-control w-25"
                    placeholder="Search by Dustbin No"
                    value={searchQuery}
                    onChange={(e) => {
                        setSearchQuery(e.target.value)

                    }}
                />
                <Button variant="primary" onClick={() => setShowAddModal(true)}>
                    Add Dustbin
                </Button>
            </div>

            {/* Dustbin List Table */}
            <Table bordered hover>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Dustbin No</th>
                        <th>Allocated Date</th>
                        <th>Last Clean Date</th>
                        <th>Garbage Qty (Kg)</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {filterList && filterList.map((dustbin, index) => (


                        <tr key={dustbin?.dustbinId}>
                            <td>{index + 1}</td>
                            <td>{dustbin?.dustNo}</td>
                            <td>{dustbin?.allocatedDate}</td>
                            <td>{dustbin?.lastCleanDate}</td>
                            <td>{dustbin?.garbageQtyInKg}</td>
                            <td>

                                <Button
                                    variant="danger"
                                    onClick={() => handleDeleteDustbin(dustbin.dustbinId)}
                                >
                                    Delete
                                </Button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </Table>

            {/* Add Dustbin Modal */}
            <Modal show={showAddModal} onHide={() => setShowAddModal(false)}>
                <Modal.Header closeButton>
                    <Modal.Title>Add Dustbin</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleAddDustbin}>
                        <Form.Group className="mb-3">
                            <Form.Label>Dustbin No</Form.Label>
                            <Form.Control
                                type="number"
                                name="dustNo"
                                value={formData.dustNo}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>garbageQtyInKg</Form.Label>
                            <Form.Control
                                type="number"
                                name="garbageQtyInKg"
                                value={formData.garbageQtyInKg}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Allocated Date</Form.Label>
                            <Form.Control
                                type="date"
                                name="allocatedDate"
                                value={formData.allocatedDate}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>User</Form.Label>
                            <Form.Select name="userId" value={formData.userId} onChange={handleChange} required>
                                <option>Select</option>
                                {usersList.map((user) => (
                                    <option key={user.userId} value={user.userId}>
                                        {user.firstName}
                                    </option>
                                ))}
                            </Form.Select>
                        </Form.Group>
                        {/* Other Fields */}
                        <Form.Group className="mb-3">
                            <Form.Label>Area</Form.Label>
                            <Form.Select name="areaId" value={formData.areaId} onChange={handleChange} required>
                                <option>Select</option>

                                {basicInfo.address.map((area) => (
                                    <option key={area.areaId} value={area.areaId}>
                                        {area.areaName}
                                    </option>
                                ))}
                            </Form.Select>
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Category</Form.Label>
                            <Form.Select name="categoryId" value={formData.categoryId} onChange={handleChange} required>
                                <option>Select</option>

                                {basicInfo.category.map((category) => (
                                    <option key={category.categoryId} value={category.categoryId}>
                                        {category.categoryName}
                                    </option>
                                ))}
                            </Form.Select>
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Status</Form.Label>
                            <Form.Select name="statusId" value={formData.statusId} onChange={handleChange} required>
                                <option>Select</option>

                                {basicInfo.status.map((status) => (
                                    <option key={status.statusId} value={status.statusId}>
                                        {status.statusName}
                                    </option>
                                ))}
                            </Form.Select>
                        </Form.Group>
                        <Button variant="primary" type="submit">
                            Add Dustbin
                        </Button>
                    </Form>
                </Modal.Body>
            </Modal>

            {/* Update Dustbin Modal */}
            <Modal show={showUpdateModal} onHide={() => setShowUpdateModal(false)}>
                <Modal.Header closeButton>
                    <Modal.Title>Update Dustbin</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleUpdateDustbin}>
                        <Form.Group className="mb-3">
                            <Form.Label>Dustbin No</Form.Label>
                            <Form.Control
                                type="number"
                                name="dustNo"
                                value={formData.dustNo}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Allocated Date</Form.Label>
                            <Form.Control
                                type="date"
                                name="allocatedDate"
                                value={formData.allocatedDate}
                                onChange={handleChange}
                                required
                            />
                        </Form.Group>
                        {/* Other Fields */}
                        <Form.Group className="mb-3">
                            <Form.Label>Area</Form.Label>
                            <Form.Select name="areaId" value={formData.areaId} onChange={handleChange} required>
                                {basicInfo.address.map((area) => (
                                    <option key={area.areaId} value={area.areaId}>
                                        {area.areaName}
                                    </option>
                                ))}
                            </Form.Select>
                        </Form.Group>

                        <Form.Group className="mb-3">
                            <Form.Label>User</Form.Label>
                            <Form.Select name="userId" value={formData.userId} onChange={handleChange} required>
                                {usersList.map((user) => (
                                    <option key={user.userId} value={user.userId}>
                                        {user.firstName}
                                    </option>
                                ))}
                            </Form.Select>
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Category</Form.Label>
                            <Form.Select name="categoryId" value={formData.categoryId} onChange={handleChange} required>
                                {basicInfo.category.map((category) => (
                                    <option key={category.categoryId} value={category.categoryId}>
                                        {category.categoryName}
                                    </option>
                                ))}
                            </Form.Select>
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Status</Form.Label>
                            <Form.Select name="statusId" value={formData.statusId} onChange={handleChange} required>
                                {basicInfo.status.map((status) => (
                                    <option key={status.statusId} value={status.statusId}>
                                        {status.statusName}
                                    </option>
                                ))}
                            </Form.Select>
                        </Form.Group>
                        <Button variant="primary" type="submit">
                            Update Dustbin
                        </Button>
                    </Form>
                </Modal.Body>
            </Modal>
        </div>
    );
}
