import React, { useEffect, useState } from 'react';
import { Modal, Button, Form, Row, Col } from 'react-bootstrap';
import { useForm } from 'react-hook-form';
import axios from 'axios';
import { getBasicInfo, getUsersList } from '../utils/api-request';

const DustbinForm = ({ show, handleClose }) => {
  const { register, handleSubmit, setValue } = useForm();
  const [statuses, setStatuses] = useState([]);
  const [areas, setAreas] = useState([]);
  const [users, setUsers] = useState([]);
  const [categories, setCategories] = useState([]);

  // Fetch data for dropdowns
  
  async function fetchData() {
    const basicData =  (await getBasicInfo()).data;
    const userData = (await getUsersList()).data;
    console.log(basicData, userData);
    
    setAreas(basicData.address);
    setCategories(basicData.category);
    setStatuses(basicData.status);
    setUsers(userData);
  }

  useEffect(() => {
    fetchData();
  }, []);

  const onSubmit = async (data) => {
    try {
      await axios.post('http://localhost:8080/api/v1/dustbins', data);
      alert('Dustbin created successfully');
      handleClose();  // Close modal after successful submission
    } catch (error) {
      console.error('Error creating dustbin:', error);
    }
  };

  return (
    <Modal show={show} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>Create Dustbin</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form onSubmit={handleSubmit(onSubmit)}>
          <Row>
            <Col sm={6}>
              <Form.Group controlId="dustbinId">
                <Form.Label>Dustbin ID</Form.Label>
                <Form.Control
                  type="number"
                  {...register('dustbinId', { required: true })}
                />
              </Form.Group>
            </Col>
            <Col sm={6}>
              <Form.Group controlId="allocatedDate">
                <Form.Label>Allocated Date</Form.Label>
                <Form.Control
                  type="date"
                  {...register('allocatedDate', { required: true })}
                />
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col sm={6}>
              <Form.Group controlId="lastCleanDate">
                <Form.Label>Last Clean Date</Form.Label>
                <Form.Control
                  type="date"
                  {...register('lastCleanDate', { required: true })}
                />
              </Form.Group>
            </Col>
            <Col sm={6}>
              <Form.Group controlId="garbageQtyInKg">
                <Form.Label>Garbage Quantity (kg)</Form.Label>
                <Form.Control
                  type="number"
                  step="0.1"
                  {...register('garbageQtyInKg', { required: true })}
                />
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col sm={6}>
              <Form.Group controlId="statusId">
                <Form.Label>Status</Form.Label>
                <Form.Control as="select" {...register('statusId', { required: true })}>
                  {statuses.map((status) => (
                    <option key={status.statusId} value={status.statusId}>
                      {status.statusName}
                    </option>
                  ))}
                </Form.Control>
              </Form.Group>
            </Col>
            <Col sm={6}>
              <Form.Group controlId="areaId">
                <Form.Label>Area</Form.Label>
                <Form.Control as="select" {...register('areaId', { required: true })}>
                  {areas.map((area) => (
                    <option key={area.areaId} value={area.areaId}>
                      {area.areaName}
                    </option>
                  ))}
                </Form.Control>
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col sm={6}>
              <Form.Group controlId="userId">
                <Form.Label>User</Form.Label>
                <Form.Control as="select" {...register('userId', { required: true })}>
                  {users.map((user) => (
                    <option key={user.userId} value={user.userId}>
                      {user.userName}
                    </option>
                  ))}
                </Form.Control>
              </Form.Group>
            </Col>
            <Col sm={6}>
              <Form.Group controlId="categoryId">
                <Form.Label>Category</Form.Label>
                <Form.Control as="select" {...register('categoryId', { required: true })}>
                  {categories.map((category) => (
                    <option key={category.categoryId} value={category.categoryId}>
                      {category.categoryName}
                    </option>
                  ))}
                </Form.Control>
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col sm={6}>
              <Form.Group controlId="dustNo">
                <Form.Label>Dust No</Form.Label>
                <Form.Control
                  type="number"
                  {...register('dustNo', { required: true })}
                />
              </Form.Group>
            </Col>
          </Row>
          <Button variant="primary" type="submit">
            Submit
          </Button>
        </Form>
      </Modal.Body>
    </Modal>
  );
};

export default DustbinForm;
