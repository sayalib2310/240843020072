import React, { useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
    const isAuthenticated = useSelector((state) => state.user.isAuthenticated);

    const user = useSelector((state) => state.user.userInfo);
    const navigation = useNavigate();
    useEffect(() => {
        console.log(user);

        if (!isAuthenticated) {
            navigation("/")
        }

    }, [])

    return (
        isAuthenticated && <div className="container mt-4">
            <h2>Dashboard</h2>
            <p>Welcome, {user ? user.firstName : 'Guest'}!</p>
        </div>
    );
};

export default Dashboard;
