import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import SweetAlert from 'sweetalert2';
import { loginUser } from '../utils/api-request'; // Function to send login request
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { login } from '../redux/store';

const UserLogin = () => {

  const isAuthenticated = useSelector((state) => state.user.isAuthenticated);

  const { register, handleSubmit, formState: { errors } } = useForm();
  const dispatch = useDispatch();
  const navigation = useNavigate();
  async function onSubmit(data) {
    console.log(data);

    const result = await loginUser(data);
    if (result.success) {
      console.log(result.data);
      // dispatch(login({...result.data,dashboardUrl:""}));
      SweetAlert.fire('Success', 'Login successful!', 'success').then(() => {
        if (result.data.role.roleId === 2) {
          dispatch(login({ ...result.data, dashboardUrl: "/admin-dashboard" }));
          navigation("/admin-dashboard")
          return;
        }
        dispatch(login({ ...result.data, dashboardUrl: "/dashboard" }));

        navigation("/dashboard")

      })
    } else {
      SweetAlert.fire('Error', `Login failed! <br/> ${result.error}`, 'error');
    }
  }

  useEffect(() => {
    if (isAuthenticated) {
      navigation("/");
    }

    return () => {

    }
  }, [])


  return (
    !isAuthenticated && <div className="d-flex justify-content-center">
      <form onSubmit={handleSubmit(onSubmit)} className="border p-4 w-50">
        <h3>User Login</h3>

        {/* Username */}
        <div className="mb-3">
          <label htmlFor="userName" className="form-label">Username</label>
          <input
            type="text"
            className="form-control"
            id="userName"
            {...register('userName', {
              required: 'Username is required',
              pattern: {
                value: /^[A-Za-z0-9_]+$/,
                message: 'Username can only contain letters, numbers, and underscores (_), no spaces allowed.'
              }
            })}
          />
          {errors.userName && <small className="text-danger">{errors.userName.message}</small>}
        </div>

        {/* Password */}
        <div className="mb-3">
          <label htmlFor="password" className="form-label">Password</label>
          <input
            type="password"
            className="form-control"
            id="password"
            {...register('password', {
              required: 'Password is required',
              minLength: {
                value: 6,
                message: 'Password must be at least 6 characters long'
              }
            })}
          />
          {errors.password && <small className="text-danger">{errors.password.message}</small>}
        </div>

        {/* Submit Button */}
        <div className="mb-3">
          <button type="submit" className="btn btn-primary">Login</button>
        </div>
      </form>
    </div>
  );
};

export default UserLogin;
