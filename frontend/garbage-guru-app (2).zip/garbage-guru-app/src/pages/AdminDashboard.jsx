import React from 'react'
import DustbinManager from './DustbinManager'

export default function AdminDashboard() {
    return (
        <div className="container mt-4">
            <h2>Dashboard</h2>
            <DustbinManager/>
        </div>
    )
}
