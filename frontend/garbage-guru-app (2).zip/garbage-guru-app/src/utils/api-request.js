// api-request/userApi.js
import axios from 'axios';

const BASE_URL = 'http://localhost:8080'; // Replace with your actual API URL

export const registerUser = async (userData) => {
  try {
    const response = await axios.post(`${BASE_URL}/users`, userData);

    if (response.data.message === 'success') {
      return { success: true, data: response.data.data };
    } else {
      return { success: false, error: response.data.data };
    }
  } catch (error) {
    console.error('Error registering user:', error.response.data);
    return { success: false, error: error.response.data.data };
  }
};

export const loginUser = async (credentials) => {
    try {
      const response = await axios.post(`${BASE_URL}/users/login`, credentials);
  
      if (response.data.message === 'success') {
        return { success: true, data: response.data.data };
      } else {
        return { success: false, error: response.data.data };
      }
    } catch (error) {
      console.error('Error logging in:', error.response?.data || error.message);
      return { success: false, error: error.response?.data?.data || 'An error occurred. Please try again.' };
    }
  };
export const adminUser = async (credentials) => {
    try {
      const response = await axios.post(`${BASE_URL}/users/admin-login`, credentials);
  
      if (response.data.message === 'success') {
        return { success: true, data: response.data.data };
      } else {
        return { success: false, error: response.data.data };
      }
    } catch (error) {
      console.error('Error logging in:', error.response?.data || error.message);
      return { success: false, error: error.response?.data?.data || 'An error occurred. Please try again.' };
    }
  };



export const getDustbins = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/dustbins`);
    console.log(response.data)
    
    return { success: true, data: response.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const getBasicInfo = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/users/basic-info`);
    console.log(response.data);
    
    return { success: true, data: response.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const getUsersList = async () => {
  try {
    const response = await axios.get(`${BASE_URL}/users`);
    console.log(response.data);
    
    return { success: true, data: response.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const addDustbin = async (dustbinData) => {
  try {
    console.log(dustbinData);
    
    const response = await axios.post(`${BASE_URL}/dustbins`, dustbinData);
    return { success: true, data: response.data.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const updateDustbin = async (dustbinId, dustbinData) => {
  try {
    const response = await axios.put(`${BASE_URL}/dustbins/${dustbinId}`, dustbinData);
    return { success: true, data: response.data.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

export const deleteDustbin = async (dustbinId) => {
  try {
    const response = await axios.delete(`${BASE_URL}/dustbins/${dustbinId}`);
    return { success: true, data: response.data.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
};
