import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { logout } from '../redux/store';

const NavBar = () => {

    const dispatch = useDispatch();
    const user = useSelector((state) => state.user.userInfo);
    const dashboardUrl = useSelector((state) => state.user.dashboardUrl);
    const isAuthenticated = useSelector((state) => state.user.isAuthenticated);
    const navigate = useNavigate();


    const handleLogout = () => {
        dispatch(logout());
        navigate("/");
    };
    return (
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <div className="container-fluid">
                <Link className="navbar-brand" to="/">GARBAGE GURU</Link>
                <div className="collapse navbar-collapse">
                    {!isAuthenticated ? (<ul className="navbar-nav ms-auto">
                        <li className="nav-item">
                            <Link className="nav-link" to="/register">Register</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/login">Login</Link>
                        </li>
                    
                    </ul>) :
                        (<ul className="navbar-nav ms-auto">
                            <li className="nav-item">
                                <Link className="nav-link" to={dashboardUrl}>Dashboard</Link>

                            </li>
                            <li className="nav-item">
                                <button className='btn btn-danger' onClick={handleLogout}>Logout</button>
                            </li>
                        </ul>)}

                </div>
            </div>
        </nav>
    );
};

export default NavBar;
